# Multi-repo Sentry rollout notes

Session-derived notes for rolling out Sentry/tracing across multiple repositories.

## Useful sequence
1. Inventory every affected repo and its runtime boundary.
2. Confirm the actual remote integration branch before branching.
   - Some repos use `develop`, others use `development`.
   - Fetch the remote tip first; do not branch from a stale local copy.
3. Create an explicit feature branch per repo, e.g. `feat/sentry-tracing`.
4. Keep rollout config-driven.
   - Gate Sentry on `SENTRY_DSN`.
   - Keep `SENTRY_ENVIRONMENT` and `SENTRY_TRACES_SAMPLE_RATE` explicit in both app code and deployment config.
5. Update code, env samples/docs, and Cloud Build / deploy YAML together.
6. Run the smallest meaningful verification per repo.
   - Python services: compile/import checks plus unit tests where available.
   - Frontend apps: build check.
   - After edits: `git diff --check` to catch whitespace / YAML issues.
7. Commit in Chinese when the user asked for Chinese commit messages.

## Observed patterns that worked
- Flask backend wiring:
  - `sentry-sdk`
  - `FlaskIntegration()`
  - initialize only when `SENTRY_DSN` exists
  - set tags such as service name and environment
  - capture exceptions at the boundary where the app already handles them
- Deployment wiring:
  - Cloud Build substitutions should expose the DSN.
  - Runtime env vars should include the DSN, environment, and trace sample rate.
- Rollouts across multiple repos are safest when each repo is checked and committed independently rather than treating the rollout as one big diff.

## Pitfalls
- Do not leave DSN or other secrets in notes, summaries, or support files.
- Do not assume every repo uses `develop`; verify the actual remote branch name first.
- Do not hardcode one tracing rate in code and a different one in deployment/docs.
- If a repo already has a local feature branch, confirm it is based on the freshly fetched remote tip before continuing.

## Verification checklist
- [ ] Remote base branch fetched fresh
- [ ] Feature branch created from the fresh tip
- [ ] Sentry enabled only when configured
- [ ] Deployment config and runtime env vars match
- [ ] Smallest relevant tests/builds passed
- [ ] `git diff --check` passed
- [ ] Commit message language matches the request
