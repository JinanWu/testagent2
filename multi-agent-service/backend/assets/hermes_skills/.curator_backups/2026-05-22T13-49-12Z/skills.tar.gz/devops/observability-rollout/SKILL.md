---
name: observability-rollout
description: Roll out Sentry or similar observability across one or more repositories with correct branch hygiene, deployment wiring, and verification.
---

# Observability rollout

Use this skill when adding Sentry, tracing, error capture, or related observability instrumentation to one or more repositories (frontend, backend, workers, or jobs).

One-line reference notes live in `references/multi-repo-sentry-rollout.md`.

## Core workflow

1. Identify every affected repository and its runtime boundaries:
   - frontend/browser instrumentation
   - backend/server tracing and exception capture
   - worker/job CLI tracing
   - deployment configs that inject env vars or build args

2. Sync the remote base branch first.
   - Fetch the latest remote branch before creating work branches.
   - Prefer the repo’s actual integration branch name (`develop`, `development`, or the project’s documented default).
   - Only branch off the freshly fetched remote tip, not an old local branch.

3. Create a dedicated feature branch per repo or coordinated rollout branch set.
   - Keep branch names explicit, e.g. `feat/sentry-tracing`.
   - If a repo already has uncommitted work, resolve that state before starting the observability changes.

4. Add observability in a way that is configuration-driven.
   - Enable Sentry only when `SENTRY_DSN` is set.
   - Keep sample rates explicit and easy to audit; do not rely on hidden defaults.
   - When the user gives a specific sampling rate, use that exact value everywhere tracing is configured.

5. Wire each runtime correctly.
   - Frontend: initialize browser monitoring early, include browser tracing integration, and propagate trace targets only to intended hosts.
   - Backend: initialize Sentry during app startup, capture exceptions at integration boundaries, and flush on shutdown when appropriate.
   - Jobs/CLI: initialize once at process start, wrap major units of work in transactions/spans, and flush before exit.

6. Propagate settings through the delivery pipeline.
   - Update `env.example`, README/docs, Dockerfiles, and build/deploy YAML together.
   - Ensure cloud/build pipelines pass both build-time and runtime env vars needed by the app.
   - Keep the deploy config consistent with the app’s own environment variable names.

7. Verify the rollout before commit.
   - Run the repo’s relevant checks: import/compile, unit tests, type checks, frontend build, or equivalent.
   - Confirm generated lockfiles or dependency manifests if package installs changed.
   - Inspect the final git diff and status to ensure there are no half-resolved merge markers.

8. Commit in the requested language.
   - When the user asks for Chinese commit messages, write the commit message in Chinese.
   - Keep the commit message short and descriptive.

## Pitfalls

- Do not hardcode one sample rate in code and a different one in docs or deployment config.
- Do not ship observability code without the deployment files that make it configurable.
- If `git stash pop` or a similar reuse step creates a conflict in `cloudbuild.yaml`, prefer reconstructing the file from the intended final state rather than leaving conflict markers behind.
- For frontend env injection, beware quoting/templating issues; use safe serialization or build-time env patterns rather than raw string interpolation where possible.
- For multi-repo rollouts, check each repo independently; one repo passing does not validate the others.

## Verification checklist

- [ ] Remote base branch fetched fresh
- [ ] Feature branch created from the fresh remote tip
- [ ] Observability enabled only when configured
- [ ] Sample rate matches the user’s requested value
- [ ] Deployment files updated
- [ ] Tests/builds/compilation passed
- [ ] Git status clean enough to commit
- [ ] Commit message in the requested language
