# User-specific Apple Reminders workflow notes

- The user's default/primary Reminders list is `提醒事項`.
- For relative deadlines phrased as `before 6pm` / `下午六點前`, convert to an exact due time of `17:59` on the target day unless the user specifies another minute.
- When the user says `today before noon`, use `11:59` as the concrete due time.
- When creating reminders through AppleScript, a reliable pattern is:
  1. Create the reminder first.
  2. Set `body` separately.
  3. Set `due date` separately.
  4. Verify with `properties of r` or a follow-up lookup.
- If a list lookup or one-shot property assignment behaves oddly, split creation and property assignment into separate steps before retrying.