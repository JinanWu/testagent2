---
name: apple-calendar
description: "Apple Calendar via Calendar.app and AppleScript/JXA for reading, searching, and updating events."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [macos]
metadata:
  hermes:
    tags: [Calendar, events, macOS, Apple, JXA, AppleScript]
prerequisites:
  commands: [osascript]
---

# Apple Calendar

Use this skill when the user wants to inspect, search, move, or edit events in Apple Calendar / Calendar.app.

## When to Use

- List calendars and events in Calendar.app
- Find events by date, title, or calendar name
- Move or resize events in Apple Calendar
- Inspect calendar data on macOS without using a third-party service

## Quick Approach

Prefer `osascript -l JavaScript` (JXA) for anything beyond a trivial one-liner.
It is usually more reliable than AppleScript when you need structured output or edits.

## Read / Search Patterns

### List calendar names
Use Calendar.app directly:
```bash
osascript -e 'tell application "Calendar" to get name of every calendar'
```

### Search events by a date range
In JXA, iterate calendars and filter by `startDate()` in a time window.
This is more reliable than complex AppleScript object-specifier filters on some systems.

Example pattern:
```javascript
var Calendar = Application('Calendar');
var start = new Date(2026, 5, 6);
var next = new Date(2026, 5, 7);
var out = [];
Calendar.calendars().forEach(function(cal) {
  cal.events().forEach(function(e) {
    var s = new Date(e.startDate());
    if (s >= start && s < next) out.push({calendar: cal.name(), summary: e.summary()});
  });
});
console.log(JSON.stringify(out, null, 2));
```

## Update Patterns

### Move an event by one day
When updating a timed event, set `endDate` before `startDate`.
That avoids the Calendar error that complains the start date must be earlier than the end date.

Recommended pattern:
1. Capture old start/end.
2. Compute new start/end.
3. Assign `endDate` first.
4. Assign `startDate` second.
5. Re-query the target date to verify.

Example:
```javascript
e.endDate = newEnd;
e.startDate = newStart;
```

### Verification
After edits, always re-query the event on the target date to confirm the move.
For date-specific operations, verify both the source date and destination date.

## Pitfalls

- Complex AppleScript date-filter queries can fail with object-specifier errors; use JXA and manual filtering instead.
- Time-zone and locale rendering in logs may differ from the actual stored event time; verify by querying the event again after update.
- Calendar edits are stateful; if a move fails halfway, re-read the event before trying again.

## Support Files

- `references/apple-calendar-jxa-snippets.md` — known-good JXA probes for listing, filtering, and moving events.

## Related Skills

- `apple-reminders` for personal to-dos and reminder lists.
