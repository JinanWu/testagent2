# Apple Calendar JXA Snippets

This file collects the working patterns for Calendar.app automation on macOS.

## List calendars
```bash
osascript -e 'tell application "Calendar" to get name of every calendar'
```

## Find events in a date window
```javascript
var Calendar = Application('Calendar');
var start = new Date(2026, 5, 6);
var next = new Date(2026, 5, 7);
var out = [];
Calendar.calendars().forEach(function(cal) {
  cal.events().forEach(function(e) {
    var s = new Date(e.startDate());
    if (s >= start && s < next) {
      out.push({
        calendar: cal.name(),
        summary: e.summary(),
        start: e.startDate().toString(),
        end: e.endDate().toString()
      });
    }
  });
});
console.log(JSON.stringify(out, null, 2));
```

## Move an event one day forward
Important: set `endDate` before `startDate`.

```javascript
var Calendar = Application('Calendar');
var oldStart = new Date(e.startDate());
var oldEnd = new Date(e.endDate());
var newStart = new Date(oldStart.getTime() + 24*60*60*1000);
var newEnd = new Date(oldEnd.getTime() + 24*60*60*1000);
e.endDate = newEnd;
e.startDate = newStart;
```

## Verification probe
After editing, query the destination day again and confirm the event appears there.
