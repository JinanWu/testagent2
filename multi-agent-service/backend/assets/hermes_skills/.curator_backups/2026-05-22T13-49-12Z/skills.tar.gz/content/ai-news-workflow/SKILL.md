---
name: ai-news-workflow
description: "Use when operating the AI Lab News and AI智報 newsletter workflow, including storage layout, roles, source-to-draft pipeline, and review handoff."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [ai-news, newsletter, workflow, editorial]
    related_skills: [ai-news-source-recon, ai-news-editorial-guardrails]
---

# AI News Workflow

## Overview

This skill defines the durable workflow for two publications:

- AI Lab News: daily AI update for the company's IT / information department.
- AI智報: weekly AI application digest for other departments.

Hermes acts as collector, editorial assistant, and gatekeeper. The user is the final reviewer and approver.

## When to Use

Use this skill when:

- Creating, updating, or running the AI Lab News / AI智報 process.
- Producing daily or weekly drafts.
- Reading or writing files under `/Users/wujinan/Documents/AI-News/`.
- Explaining the newsletter production pipeline.

Do not use this skill for unrelated content writing.

## Canonical Storage Root

Use this root unless the user explicitly changes it:

`/Users/wujinan/Documents/AI-News/`

Important files:

- `sources/source_registry.json` — machine-readable source registry.
- `sources/source_registry.md` — human-readable source table.
- `templates/ai-lab-news-daily-template.md` — daily template.
- `templates/ai-zhibao-weekly-template.md` — weekly template.
- `templates/review-checklist.md` — review checklist.
- `data/raw/YYYY-MM-DD.jsonl` — raw collected items.
- `data/normalized/YYYY-MM-DD.jsonl` — normalized items.
- `data/shortlist/YYYY-MM-DD.md` — filtered shortlist.
- `AI Lab News/YYYY-MM-DD/publication.md` — review-ready publication candidate, written as if publishable but not yet approved.
- `AI Lab News/YYYY-MM-DD/sources.md` — sources actually used in the publication plus excluded/downgraded candidates.
- `AI Lab News/YYYY-MM-DD/diff_check.md` — comparison with the previous issue and recent-duplicate check.
- `AI Lab News/YYYY-MM-DD/review_package.md` — index for reviewer handoff.
- `AI Lab News/YYYY-MM-DD/draft.md` — optional internal working draft; do not treat this as the user-facing review artifact.
- `AI智報/YYYY-Www/draft.md` — weekly draft.

## Workflow

1. Collect from fixed sources.
2. Store raw items before writing any prose.
3. Normalize fields and preserve canonical URLs.
4. Filter, dedupe, and grade items.
5. Produce a review package, not just an internal draft:
   - `publication.md`: review-ready publication candidate, with no editor-only notes in the main body.
   - `sources.md`: sources actually used, plus excluded/downgraded candidates.
   - `diff_check.md`: compare against the previous `publication.md` and flag recent duplicates; if no previous issue exists, say so explicitly.
   - `review_package.md`: reviewer-facing index and checklist.
6. Wait for user review before treating anything as final.

## Publication Rules

### AI Lab News

- Audience: IT / information department.
- Cadence: daily.
- Length: 3-5 key items.
- Focus: latest changes, tools, API/model updates, technical observations, risk notes.

### AI智報

- Audience: other departments.
- Cadence: weekly.
- Focus: plain-language summary, useful tools, workplace cases, small tips, reusable prompts.
- Derive from daily materials; do not restart from scratch unless requested.

## Hard Rules

- Never publish automatically.
- Always preserve source links.
- Do not include a `導入可能性` field.
- Social/media sources may supplement but should not be the sole authority for a claim.
- Mark uncertain information explicitly.

## Verification Checklist

- [ ] Output stayed under `/Users/wujinan/Documents/AI-News/`.
- [ ] Source links are preserved.
- [ ] Draft is clearly not final.
- [ ] No `導入可能性` field appears.
