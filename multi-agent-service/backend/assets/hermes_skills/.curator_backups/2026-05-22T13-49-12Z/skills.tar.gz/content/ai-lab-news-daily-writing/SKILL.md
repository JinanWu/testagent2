---
name: ai-lab-news-daily-writing
description: Use when writing or reviewing AI Lab News daily drafts for the company IT or information department.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [ai-news, daily, writing, newsletter]
    related_skills: [ai-news-workflow, ai-news-editorial-guardrails]
---

# AI Lab News Daily Writing

## Overview

AI Lab News is a daily AI update for the company's IT / information department. It should be concise, high-signal, and source-backed.

## When to Use

Use this skill when:

- Producing an AI Lab News daily draft.
- Reviewing an AI Lab News draft.
- Converting a shortlist into a daily issue.

## Audience

Primary audience: IT / information department colleagues.

They care about:

- AI product and API changes.
- Coding-agent and Copilot/Codex/Claude Code changes.
- Tool updates.
- Risk, deprecation, privacy, security, or breaking changes.

## Template

Canonical template path:

`/Users/wujinan/Documents/AI-News/templates/ai-lab-news-daily-template.md`

Recommended subtitle:

`每日重點、工具更新、技術觀察、風險提醒`

Sections:

1. 今日一句話摘要
2. 重要更新
3. 技術觀察
4. 風險提醒
5. 來源連結

## Writing Rules

- Include 3-5 main items only.
- Prefer official sources and changelogs.
- Write `publication.md` as a publishable, opinionated report, not a directory or bullet digest. It should have a clear editorial thesis, descriptive context, reasoning, and implications for the IT / information department.
- Use bullets sparingly inside the article; they may support the argument but should not replace narrative explanation.
- Explain why each item matters to technical colleagues.
- Include source URL for every item.
- Mark uncertainty explicitly.
- Do not include a `導入可能性` field.

## Review Checklist

- [ ] 3-5 items.
- [ ] Every item has a source.
- [ ] Suitable for IT/information department readers.
- [ ] Includes technical observation or risk note.
- [ ] No `導入可能性` field.
