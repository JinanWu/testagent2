# Flask + Sentry notes

Session-derived minimal pattern for a Flask API:

- Add `sentry-sdk` to dependencies.
- Load env vars first, then initialize monitoring only when `SENTRY_DSN` is present.
- Use `FlaskIntegration()` for framework hooks.
- Set tracing explicitly, e.g. `traces_sample_rate=0.05` for low-volume production sampling.
- Keep `send_default_pii=False` unless there is a clear reason to send user-identifying data.
- Call `sentry_sdk.capture_exception(e)` in `except` blocks that intentionally translate failures into JSON responses.
- Capture both request-handler exceptions and helper-level exceptions when helper code swallows errors and returns per-item failure objects.
- Add README notes for `SENTRY_DSN` and the sample rate so dev/prod behavior is obvious.

Practical rule:

- Unhandled exceptions are usually captured automatically.
- Handled exceptions are not; capture them before returning a response if they matter operationally.
