# Survey ETL API field discovery (session note)

This note captures the practical pattern used for the passenger-survey ETL source APIs.

## Endpoints

- `label-analyze`:
  - `https://feedback-survey-service-586561863834.asia-east1.run.app/report/customer-feedback/label-analyze`
- `ai-label`:
  - `https://feedback-survey-service-586561863834.asia-east1.run.app/report/customer-feedback/ai-label`

## Query pattern

Use a tight month window with the API’s expected query params:

- `startDateTime=YYYY-MM-01T00:00:00`
- `endDateTime=YYYY-MM-31T23:59:59`

For the May slice used in this session:

- `2026-05-01T00:00:00`
- `2026-05-31T23:59:59`

## What we checked

1. Called both endpoints directly.
2. Inspected only the first 2–3 rows.
3. Compared key sets.
4. Separated fields into shared vs endpoint-specific.

## Observed shapes

### label-analyze
- Returned `data` with 11,296 rows for the May slice.
- First rows shared a 44-field shape.
- Core fields included:
  - `appoint_no`, `opinion_no`, `suggestion_describe`
  - `tour_code`, `tour_name`, `tour_date`
  - `leader_Id_No`, `leader_name`
  - `tour_guide_seq_no`, `tour_guide_name`
  - `leader_and_guide_flag`
  - `create_time`
- HM fields (16) and AI fields (16) were both present.

### ai-label
- Returned `data` with 10,526 rows for the May slice.
- First rows shared a 30-field shape.
- Core fields were the same as above except the HM fields were absent.
- Extra fields present only here:
  - `ai_sentiment_label`
  - `ai_sentiment_score`

## Practical notes

- If one environment returns empty results, check another environment before assuming the endpoint schema changed.
- `tour_name` can be sampled directly from the returned rows; a few distinct examples are usually enough for review.
- `create_time` may be populated on one endpoint and null on another; treat it as endpoint-specific behavior, not necessarily a schema mismatch.
