# Python docstring convention for helper functions

Use this format for helper / integration / initialization functions in Python codebases where readability matters.

## Recommended order

1. Summary sentence in Chinese
2. Environment / fallback order
3. Args
4. Returns
5. Examples
6. Raises

## Template

```python
def init_sentry(api_env: Optional[str] = None) -> bool:
    """
    在 ``SENTRY_DSN`` 已設定且 ``sentry-sdk`` 可用時初始化 Sentry。

    Environment 解析順序為 ``SENTRY_ENVIRONMENT``、傳入的 ``api_env``、
    ``API_ENV``，最後才使用 ``"development"``。初始化時會固定使用
    ``SENTRY_TRACES_SAMPLE_RATE``，並啟用 logging 與 requests integration。

    Args:
        api_env (Optional[str]): CLI 或設定層解析出的 API 環境；當
            ``SENTRY_ENVIRONMENT`` 未設定時作為 Sentry environment fallback。

    Returns:
        bool: 成功初始化 Sentry 時回傳 True；未設定 DSN 或套件不可用時回傳 False。

    Examples:
        >>> import os
        >>> os.environ.pop("SENTRY_DSN", None)
        >>> init_sentry("development")
        False

    Raises:
        本函式不主動拋出錯誤；若 ``sentry_sdk.init`` 因 SDK 內部錯誤失敗，會由 SDK
        原樣拋出。
    """
```

## Writing rules

- The summary should state the function's purpose in one sentence.
- The Environment section should always show precedence order when config can come from multiple places.
- Args should explain the role of each input, not repeat the type information alone.
- Returns should state the observable behavior, especially success/failure booleans.
- Examples should be minimal and runnable when possible.
- Raises should say "does not proactively raise" if that is the real behavior.
- Prefer Chinese prose for the body when the surrounding project documentation is Chinese.
