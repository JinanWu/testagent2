---
name: python-observability
description: "Integrate observability into Python services: Sentry-style error capture, tracing, and safe runtime wiring."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Python, observability, monitoring, Sentry, tracing, error-capture]
---

# Python Observability

Use this skill when adding or modifying observability in a Python service, especially web APIs (Flask/FastAPI/Django) that need error capture, tracing, and release-aware debugging.

## Typical goals

- Capture unhandled exceptions automatically
- Report intentionally handled failures with context
- Add performance tracing with a controlled sample rate
- Keep initialization safe when monitoring is disabled by env var
- Document the runtime knobs for developers and deployers

## Standard workflow

1. Identify the framework and request lifecycle
   - Flask/Werkzeug style apps often benefit from framework-specific integrations.
   - ASGI/WSGI wrappers may need the SDK initialized before request handling begins.

2. Prefer a structured docstring for helper functions
   - For small helper functions that initialize monitoring, capture exceptions, or derive runtime config, use a consistent Chinese docstring structure.
   - Recommended sections: summary, Environment, Args, Returns, Examples, Raises.
   - Keep the Environment block explicit about fallback order, default values, and which env vars enable/disable the feature.
   - Keep Args/Returns terse but precise; prefer clear boolean semantics for init helpers.
   - If the function does not proactively raise, say so directly in Raises.
   - See `references/python-docstring-convention.md` for a reusable template.

2. Add the SDK dependency
   - Add the monitoring SDK to the dependency file.
   - Prefer a pinned lower bound that matches the codebase's Python version.

3. Initialize from environment variables
   - Read the DSN/token from an env var.
   - If the env var is missing, skip initialization cleanly.
   - Configure tracing explicitly instead of using an implicit default.

4. Add error capture where failures are intentionally swallowed
   - Unhandled exceptions are usually captured automatically.
   - If an exception is caught and converted into an HTTP response, call `capture_exception(...)` before returning.
   - Keep validation errors out of monitoring unless they represent a real product bug.

5. Document the knobs
   - Add README notes for the env var(s) and expected behavior.
   - Mention sample rates and what is captured in dev vs prod.

6. Verify
   - Run a syntax/import check.
   - Start the app locally and trigger a controlled exception.
   - Confirm that the event appears in the monitoring dashboard.

## Flask-specific guidance

- Prefer `FlaskIntegration()` when using `sentry_sdk` with Flask.
- Initialize after loading environment variables, before serving requests.
- If the app has both single-request and batch-request handlers, capture exceptions in each handler path.
- If helper functions convert exceptions into per-item failure objects, capture those failures at the helper boundary so the issue still reaches monitoring.

## Pitfalls

- Do not hardcode DSN values in source.
- Do not use a high trace sample rate in production unless you truly need the volume.
- Do not capture expected client validation errors by default; that creates noise.
- Do not forget to document the monitoring env var; otherwise local and CI runs become confusing.
- If you catch an exception and return an error response, the exception will not automatically reach monitoring unless you explicitly capture it.

## Verification checklist

- Dependency added and installable
- SDK initializes only when monitoring config is present
- One controlled exception appears in the monitoring backend
- Trace sampling matches the intended rate
- README or deployment docs mention the runtime flag/env var

## Support files

- `references/sentry-flask.md` — concise Flask/Sentry integration notes and the session pattern used here.
