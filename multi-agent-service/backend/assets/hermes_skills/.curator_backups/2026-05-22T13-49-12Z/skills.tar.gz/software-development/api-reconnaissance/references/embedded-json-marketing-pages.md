# Embedded JSON on marketing pages

Use this pattern when a page looks like a normal HTML landing page but the real product data is embedded in a script tag or JS constant.

## Quick recipe

1. Fetch the HTML source directly.
2. Search for a large JSON assignment, often patterns like:
   - `const contents = [...]`
   - `window.__INITIAL_STATE__ = {...}`
   - `var data = {...}`
3. Extract the JSON slice with bracket matching rather than regex alone.
4. Parse it and walk recursively.
   - Category labels may live at multiple levels (`class1Name`, `class2Name`, `class2PageName`).
   - Real product rows usually have `contentTitle` and sometimes `contentUrl`.
5. For prices, prefer this fallback order:
   - `priceText`
   - `defaultPriceText`
   - `defaultPrice`
   - `priceInfoText`
6. Skip container nodes that only group child products and have no `contentTitle`.
7. Report a small representative sample per category, then summarize min/max when numeric prices exist.

## Why this helps

A lot of travel / retail / marketing pages render data client-side, but the HTML source already contains a complete, machine-readable snapshot. Parsing the source is usually faster and more reliable than UI automation.
