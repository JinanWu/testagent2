---
name: api-reconnaissance
description: Inspect HTTP APIs for field schemas and representative samples with minimal payloads.
---

# API reconnaissance

Use this skill when the task is to inspect an API’s returned fields, compare two or more endpoints, or extract a few representative values without dumping large payloads.

## Core workflow

1. Locate the real endpoint or embedded data source first.
   - Check the repo for endpoint constants, environment routing, and parameter names.
   - Prefer the exact code path the pipeline uses rather than guessing URLs.
   - For marketing / travel landing pages, inspect the HTML source for embedded JSON constants before reaching for browser automation.

2. Query a narrow time window.
   - If the user asks for “5月” or another month, use that month’s start/end timestamps.
   - Keep the query as specific as possible so the sample is representative and cheap.

3. Sample only a few rows.
   - Inspect 2–3 rows, not entire payloads.
   - Derive the field list from the sample and report the union of keys.
   - Avoid large record dumps unless the user explicitly asks.

4. Compare endpoints side by side.
   - Separate fields into: shared fields, endpoint-specific fields, optional/null fields, and time fields.
   - If one endpoint returns a superset, call that out explicitly.

5. Verify the result.
   - Report URL, params, status code, record count, and field count.
   - When useful, include one representative record with only the important fields.

6. Flatten nested product trees when the source is hierarchical.
   - Traverse recursively and carry category labels from ancestor nodes.
   - Treat nodes without `contentTitle` as containers unless they clearly represent a product row.
   - Prefer `priceText`, then `defaultPriceText`, `defaultPrice`, and `priceInfoText` for the displayed price.

## Helpful output pattern

- Endpoint A: count, field count, shared fields, unique fields
- Endpoint B: count, field count, shared fields, unique fields
- Example values: 2–3 distinct values for the requested field

## Pitfalls

- Don’t assume a missing field means the schema lacks it; it may be null, environment-specific, or only present in another endpoint.
- Don’t use broad date ranges if the user only wants a monthly slice.
- Don’t dump long example records when a few field names or values answer the question.
- Always check the code/config for the exact parameter names before querying.

## Related reference

- `references/survey_api_field_discovery.md` — survey ETL example: how we identified the two source APIs, queried May data, and compared their field sets.
- `references/embedded-json-marketing-pages.md` — how to extract hierarchical product data from JSON embedded in HTML source pages.
