# Monitoring a website and creating Apple Reminders when new items appear

This pattern was used for the 永豐投顧 "個股脈動" feed.

## Goal

Run on a schedule, compare current items against a stored seen-state, and create Apple Reminders only for newly observed items.

## Key implementation points

- Fetch the public page first, then submit the AJAX request the page uses internally.
- When the site uses an anti-forgery token, extract it from the homepage HTML and send it back with the POST request.
- For the SCM site, the relevant endpoint was:
  - `POST https://scm.sinotrade.com.tw/Article/GetSubscribeList`
  - `ServiceGUID = 2b545beb-df74-44eb-bf14-3248fe311cdd` for 台股報告 / 個股脈動
- Use a local JSON state file to store seen item IDs so the first run establishes a baseline instead of backfilling all historical items.
- When a new item appears, create an Apple Reminder in the primary list `提醒事項` with a title like `閱讀投顧研究報告：<報告標題>` and include the source link in the body.

## Pitfalls

- Do not rely on the page's visible HTML alone; some content is loaded by JavaScript from an API endpoint.
- The first run should usually be silent except for establishing the baseline state.
- Use a stable item key such as GUID or ID; avoid title-only deduplication because titles can repeat or change format.
- If the reminder title is too generic, it's hard to tell which report triggered it later; include the original report title.

## Verification

- Run the fetch script once and confirm it prints nothing when there are no new items.
- Confirm the state file contains a non-empty set of seen keys after baseline initialization.
- Trigger a new-item path and verify a reminder appears in `提醒事項` with the expected title/body.
