---
name: apple-reminders
description: "Apple Reminders via remindctl: add, list, complete."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [macos]
metadata:
  hermes:
    tags: [Reminders, tasks, todo, macOS, Apple]
prerequisites:
  commands: [remindctl]
---

# Apple Reminders

Use Apple Reminders to manage personal tasks that sync across Apple devices via iCloud.

Current user environment note: `remindctl` is not installed on the user's Mac. Do not try `remindctl` first unless a fresh prerequisite check shows it is available. Prefer the built-in `osascript -l JavaScript` / JXA fallback for creating, editing, and verifying reminders.

## Prerequisites

- **macOS** with Reminders.app
- Install: `brew install steipete/tap/remindctl`
- Grant Reminders permission when prompted
- Check: `remindctl status` / Request: `remindctl authorize`

## When to Use

- User mentions "reminder" or "Reminders app"
- Creating personal to-dos with due dates that sync to iOS
- Managing Apple Reminders lists
- User wants tasks to appear on their iPhone/iPad

## When NOT to Use

- Scheduling agent alerts → use the cronjob tool instead
- Calendar events → use Apple Calendar or Google Calendar
- Project task management → use GitHub Issues, Notion, etc.
- If user says "remind me" but means an agent alert → clarify first

## Quick Reference

### View Reminders

```bash
remindctl                    # Today's reminders
remindctl today              # Today
remindctl tomorrow           # Tomorrow
remindctl week               # This week
remindctl overdue            # Past due
remindctl all                # Everything
remindctl 2026-01-04         # Specific date
```

### Sprint-style weekly planning
Use Reminders as a lightweight sprint backlog when the user wants weekly planning:
- Keep three layers: backlog, this week, today.
- Encode priority in the title prefix, e.g. `[P0]`, `[P1]`, `[P2]`.
- Encode size in the title prefix, e.g. `[SP1]`, `[SP3]`, `[SP5]`.
- Use the note/body for next step, dependency, and definition of done.
- Put true deadlines in due dates; items committed for the current week can use Friday 17:59 as the soft weekly cutoff if the user wants a weekly sprint boundary.
- Review unfinished work at the start of the week, then re-plan each workday in a short standup-style check-in.
- When the user asks to decompose one reminder into smaller work items, rewrite the body as 5-8 numbered story-sized subtasks, and explicitly label async/batched/non-blocking processing where relevant.

See `references/user-reminders-workflow.md` for the user-specific conventions.

## Fallback when `remindctl` isn't available

Use `osascript` for inspection and edits. Prefer `osascript -l JavaScript` when you need structured output or reliable writes; see `references/apple-reminders-applescript.md` for read-only AppleScript notes and `references/apple-reminders-javascript-fallback.md` for known-good JavaScript snippets.

Practical tip: for create/update flows, it is often more reliable to:
1. create the reminder with just a title,
2. set `body` and `due date` in a second pass,
3. verify with `properties of` the reminder.

This avoids edge cases where a single long `make new reminder ... with properties {...}` call does not persist every field as expected.

For write operations, prefer a staged flow: create the reminder with the title first, then set `body` and `due date` separately, and verify by reading back the reminder state. See `references/apple-reminders-session-notes.md` for a known-good recipe.

For write operations, prefer a staged flow: create the reminder with the title first, then set `body` and `due date` separately, and verify with `properties of r`. See `references/apple-reminders-session-notes.md` for a known-good recipe.

### Common read-only probes:
- list names: `osascript -e 'tell application "Reminders" to get name of every list'`
- reminders in one list: `osascript -e 'tell application "Reminders" to get name of every reminder of list "Personal"'`
- unfinished inventory for a specific list: `osascript -e 'tell application "Reminders" to get {name, completed} of every reminder of list "提醒事項"'`
- for inventory requests, prefer exact-name lookup of `提醒事項` and filter `completed == false`; keep due dates visible when present
- structured list names / reminder status: use `osascript -l JavaScript` from `references/apple-reminders-javascript-fallback.md`
- read-only probe examples and quoting notes: `references/apple-reminders-read-only-probes.md`
- unfinished-inventory notes and output shape: `references/user-reminders-inventory.md`
- list counts: AppleScript can iterate all lists and count reminders when you need a quick inventory

### Manage Lists

```bash
remindctl list               # List all lists
remindctl list Work          # Show specific list
remindctl list Projects --create    # Create list
remindctl list Work --delete        # Delete list
```

### Create Reminders

```bash
remindctl add "Buy milk"
remindctl add --title "Call mom" --list Personal --due tomorrow
remindctl add --title "Meeting prep" --due "2026-02-15 09:00"
```

### Complete / Delete

```bash
remindctl complete 1 2 3          # Complete by ID
remindctl delete 4A83 --force     # Delete by ID
```

### Output Formats

```bash
remindctl today --json       # JSON for scripting
remindctl today --plain      # TSV format
remindctl today --quiet      # Counts only
```

## Date Formats

Accepted by `--due` and date filters:
- `today`, `tomorrow`, `yesterday`
- `YYYY-MM-DD`
- `YYYY-MM-DD HH:mm`
- ISO 8601 (`2026-01-04T12:34:56Z`)

## Rules

1. When user says "remind me", clarify: Apple Reminders (syncs to phone) vs agent cronjob alert
2. Always confirm reminder content and due date before creating
3. Use `--json` for programmatic parsing
4. User-specific workflow notes and deadline conventions live in `references/user-reminders-workflow.md` (including the user's evening-time convention: phrases like `晚上` mean the PM version of the stated clock time)
5. If the user asks about Calendar.app events, switching dates, or moving meetings, use the separate `apple-calendar` skill instead of trying to force it into Reminders workflows.

## Related Skills

- `apple-calendar` for Calendar.app event inspection and edits
